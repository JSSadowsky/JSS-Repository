//
//  testFuctions.swift
//  Swift-Cmd-Line
//
//  Created by John Sadowsky on 2/25/15.
//  Copyright (c) 2015 John Sadowsky. All rights reserved.
//

import Foundation

func mutateSlice(inout slice: Slice<Int>)
{
  slice[ Int(rand())&slice.count ] = Int(rand())
}


func makeSlices_2(n: Int, flag: Bool) -> (a0: ContiguousArray<Int>, arrSlice: ContiguousArray<Slice<Int>>)
{

  // Initialize an array with lots of insertions and no provided capacity info
  var a0 = ContiguousArray<Int>(count: 2*n, repeatedValue: 0)
  
  sleep(1)

  // Make 3 Slice s
  var ax = ContiguousArray<Slice<Int>>(count: 3, repeatedValue: [])

  ax[0] = a0[0..<n]
  if flag { mutateSlice(&ax[0]) }       // if flag, force reallocation
  
  for i in 1..<3
  {
    sleep(1)
    ax[i] = ax[i-1][0..<(n-i)]     // slices of slices
    if flag { mutateSlice(&ax[i]) }     // if flag, force reallocation
  }
  
  sleep(1)
  
  return (a0,ax)

}

func makeSlices(n: Int, flag: Bool) -> ContiguousArray<Slice<Int>>
{
  return makeSlices_2(n, flag).arrSlice
}


////////////////////////////////////////////////////////////
// Tests

// Test 1: Make Slices without forcing reallocation

func testVarSlice_1 (n: Int)
{
  sleep(2)
  let p = makeSlices_2(n, false)
}

// Test 2: Make Slices forcing reallocation of each Slice
func testVarSlice_2 (n: Int)
{
  sleep(2)
  let pr = makeSlices_2(n, true)
}

// Test 3: Make slices forcing reallocation, wait, release a0, wait
func testVarSlice_3 (n: Int)
{
  sleep(2)
  let ax = makeSlices(n, true)
  sleep(1)
}


// Test 4: Make slices (wo/ reallocate), then sequentially mutate slices
func testVarSlice_4 (n: Int)
{
  
  sleep(2)
  
  var ax = makeSlices(n, false)
  
  // Random Mutations of
  for i in 0..<3
  {
    sleep(1)
    mutateSlice( &ax[i] )
  }
  sleep(1)
  
}

