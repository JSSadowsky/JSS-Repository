//
//  main.swift
//  Swift-Cmd-Line
//
//  Created by John Sadowsky on 2/25/15.
//  Copyright (c) 2015 John Sadowsky. All rights reserved.
//
//  This code test reallocation behavior for slices.  To perform the tests, I created
//  a simpl OS X council application - in order to eliminate UI overhead.  I then
//  run as Profile with the Allocations Insturment.  The tests have sleep() pauses so
//  as the Profile runs you can see the allocations and de-allocations as steps in the
//  Allocations Instrument chart.
//
//  All the tests are based on a makeSlices() function that creates a "base" Array a0
//  and an Array of 3 Slices/subSlices of a0.  The size of the base Array a0 is n
//  set in this file.  Make n large enough that any other miscellaneous allocations
//  the system does are insignificant relative to the Array and Slice allocations.
//

import Foundation


//////////////////////////////////

let n = 100000

// Test 1: Make slices without forcing reallocation.
//         Only one implementation object is created.

testVarSlice_1(n)

// Test 2: Make Slices and force Slice reallocation after each Slice construction.
//         There are 4 implementation objects created - a0 and the 3 Slices.  Since
//         a0 has size 2n, the step in total memory allocation for the a0 implementation
//         is twice as big as the implementations created for the Slices.

testVarSlice_2(n)

// Test 3: Make slices forcing reallocation, wait, release a0, wait.
//         Same as Test 2, except here you can see the deallocation of the a0 implementation
//         before the Slice deallocations occur.

testVarSlice_3(n)

// Test 4: Make slices (wo/ reallocate like Test 1), then sequentially mutate each of the Slices
//         Notice here that after a0 is allocated (as in Test 1), there are only two steps as
//         the slices are reallocated.  Keep in mind that the Slice reallocation objects are
//         half as big as the original a0 object.  That happens because when the 3rd Slice mutated,
//         it is the sole owner of the original a0 implementation object.  Thus, no reallocation
//         occurs on the 3rd mutation.

testVarSlice_4(n)



